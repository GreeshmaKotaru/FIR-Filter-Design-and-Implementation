#include <stdint.h>

#define NUM_TAPS 16

// Define the coefficients of the FIR filter
const int16_t coefficients[NUM_TAPS] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 90, 80, 70, 60, 50, 40};

// Function to perform FIR filtering
void fir_filter(int16_t input_sample, int16_t *output_sample) {
    static int16_t shift_register[NUM_TAPS] = {0}; // Shift register to store previous input samples

    int32_t acc = 0;

    // Shift input samples into the shift register
    for (int i = NUM_TAPS - 1; i >= 1; i--) {
#pragma HLS PIPELINE II=1
        shift_register[i] = shift_register[i - 1];
    }
    shift_register[0] = input_sample;

    // Perform the filtering operation
    for (int i = 0; i < NUM_TAPS; i++) {
#pragma HLS PIPELINE II=1
        acc += shift_register[i] * coefficients[i];
    }

    *output_sample = acc >> 15; // Scale down the result
}
