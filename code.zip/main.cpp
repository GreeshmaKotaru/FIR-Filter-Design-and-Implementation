#include <stdio.h>
#include <stdint.h>

// Function prototype for FIR filter
void fir_filter(int16_t input_sample, int16_t *output_sample);

int main() {
    // Input and output sample buffers
    int16_t input_samples[10] = {100, 200, 300, 400, 500, 600, 700, 800, 900, 1000};
    int16_t output_samples[10];

    // Apply the FIR filter to each input sample
    for (int i = 0; i < 10; i++) {
        fir_filter(input_samples[i], &output_samples[i]);
    }

    // Print the filtered output
    printf("Filtered output samples:\n");
    for (int i = 0; i < 10; i++) {
        printf("%d\n", output_samples[i]);
    }

    return 0;
}
